（绿色免安装）IDEA 201mybatis plugin7版的插件
version: v2.9.2
适配系统：mac和windows